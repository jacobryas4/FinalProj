<?php

/*
 * Author: Adam Patrick
 * Date: 11/16/18
 * File Name: user_index_view.class.php
 * Description: 
 */

class UserIndexView extends IndexView{
    
    public static function displayHeader($title){
        parent::displayHeader($title);
    }
    
    public static function displayFooter(){
        parent::displayFooter();
    }
}

