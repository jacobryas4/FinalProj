<?php

/*
 * Author: Adam Patrick
 * Date: 11/11/18
 * File Name: account_index_view.class.php
 * Description: 
 */

class AccountIndexView extends IndexView{
    
    public static function displayHeader($title){
        parent::displayHeader($title);
    }
    
    public static function displayFooter(){
        parent::displayFooter();
    }
}
