<?php

/*
 * Author: Adam Patrick
 * Date: 11/11/18
 * File Name: account_detail.class.php
 * Description: Displays details of the selected account
 */

class AccountDetail {
    
}
