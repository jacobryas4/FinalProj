<?php

/**
 * Author: Adam Patrick
 * Date: 11/29/18
 * File: data_length_exception.class.php
 * Description: Handles a data length exception
 */
class DataLengthException extends Exception {
    //No need for any code
}
