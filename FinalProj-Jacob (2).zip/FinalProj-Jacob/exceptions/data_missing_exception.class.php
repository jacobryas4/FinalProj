<?php

/**
 * Author: Adam Patrick
 * Date: 11/29/18
 * File: data_missing_exception.class.php
 * Description: An exception class that handles a missing data exception
 */
class DataMissingException extends Exception {
    //No need for any code
}
